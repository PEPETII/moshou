// Enemy：死亡、召唤与核心交互
Enemy.prototype.die = function() {
    if (this.dead) return;
    this.dead = true;
    this.deathTime = Date.now();
    this.game.ink += this.reward;
    // 首领被斩：交给首领流程（横幅、剩余时间、胜负）
    if (this.isBoss && typeof BossFlow !== 'undefined') BossFlow.onBossDeath(this.game, this);
    this.game.kills = (this.game.kills || 0) + 1;
    this.game.updateUI();

    // 击杀时播放墨散音效并生成粒子。
    if (window.InkAudio) window.InkAudio.play('death', { variant: window.InkAudio.deathVariantOf(this) });
    // 字形招式击杀由 GlyphFX.kill 出墨点碎字；反馈关闭时仍用旧爆散，避免死得毫无表现
    if (!(this.lastHitKind && typeof GlyphFX !== 'undefined' && GlyphFX.feedback)) {
      this.game.particleSystem.createExplosion(this.x, this.y, 15);
    }

    // 死亡爆炸
    if (this.explodeOnDeath) {
      // 死亡爆炸伤害玩家的路径塔；globalExplosion 视为覆盖全图
      const blastRange = this.globalExplosion ? 100 : this.explodeRange;
      this.game.triggerExplosion(this.x, this.y, this.explodeDamage, blastRange);
    }

    if (this.split) {
      this.game.spawnSplitEnemy(this);
    }
    
    // 死亡召唤
    if (this.summonOnDeath) {
      const summonType = this.deathSummonType || this.summonType;
      const summonCount = this.deathSummonCount || this.summonCount;
      if (summonType && this.game && typeof this.game.spawnEnemyAt === 'function') {
        for (let i = 0; i < summonCount; i++) {
          this.game.spawnEnemyAt(summonType, this.s, this.x, this.y);
        }
      }
    }
    
    // 毒雾效果
    if (this.poisonCloudOnDeath) {
      this.createPoisonCloud();
    }
  
};
// 召唤敌人
Enemy.prototype.summonEnemies = function() {
    if (!this.summonType || !this.game.spawnEnemyAt) return;
    
    for (let i = 0; i < this.summonCount; i++) {
      this.game.spawnEnemyAt(this.summonType, this.s, this.x, this.y);
    }
  
};
// 创建毒雾
Enemy.prototype.createPoisonCloud = function() {
    // 创建毒雾区域效果
    if (this.game.particleSystem) {
      this.game.particleSystem.createPoisonCloud(this.x, this.y, this.poisonCloudDuration, this.poisonCloudDamage);
    }
  
};
// 远程攻击
Enemy.prototype.performRangedAttack = function() {
    // 简化实现：对范围内的随机炮塔造成伤害
    if (!this.game.towers || this.game.towers.length === 0) return;
    
    const rangePixels = this.range * CONFIG.CELL_SIZE;
    const targets = this.game.towers.filter(tower => {
      const dx = tower.x - this.x;
      const dy = tower.y - this.y;
      return Math.sqrt(dx * dx + dy * dy) <= rangePixels;
    });
    
    if (targets.length > 0) {
      const target = targets[Math.floor(Math.random() * targets.length)];
      if (target.takeDamage) {
        target.takeDamage(this.damage);
      }
    }
  
};
Enemy.prototype.reachCore = function() {
    // 首领到达核心：不走普通扣血，由首领流程处理（扣核心上限一半并回到入口，第二次直接判负）
    if (this.isBoss && typeof BossFlow !== 'undefined') { BossFlow.onReachCore(this.game, this); return; }
    this.dead = true;
    this.game.leaks = (this.game.leaks || 0) + 1;
    this.game.coreHp -= this.damage;
    
    // 吸血效果 - 蚂蟥等怪物攻击核心时回复生命
    if (this.lifeSteal > 0) {
      this.hp = Math.min(this.maxHp, this.hp + this.lifeSteal);
    }
    
    this.game.updateUI();

    // 核心受击时播放纸裂音效。
    if (window.InkAudio) window.InkAudio.play('core');

    if (this.game.coreHp <= 0) {
      this.game.gameOver(false);
    }
  
};
